var style = document.createElement("style");
style.innerHTML = ".x-tree-no-lines .x-tree-elbow-end-plus," +
    ".x-tree-elbow-img," +
    ".x-tree-no-lines .x-tree-elbow-end-minus {" +
    "background-image: none;" +
    "visibility:hidden;" +
    "} ";
document.getElementsByTagName("head")[0].appendChild(style);

// Requires
Ext.syncRequire(['Ext.util.Cookies', 'Ext.window.MessageBox']);
//MENU
var myCookie = Ext.util.Cookies;
var Menu = Ext.create('Ext.panel.Panel', {
    layout: 'fit',
    border: false,
    bodyPadding: 0,
    border: 0,
    items: [{
        xtype: 'buttongroup',
        columns: 3,
        items: [{
            text: 'File',
            arrowAlign: 'right',
            menu: [{
                text: 'Menu Item 1',
                listeners: {
                    click: function(a, b) {
                        console.log(a, b);
                    }
                }
            }, {
                text: 'Menu Item 2'
            }, {
                text: 'Menu Item 3'
            }, {
                text: 'Menu Item 4'
            }, {
                text: 'Menu Item 5'
            }]
        }, {
            text: 'Edit',
            arrowAlign: 'right',
            menu: [{
                text: 'Menu Item 1'
            }, {
                text: 'Menu Item 2'
            }, {
                text: 'Menu Item 3'
            }, {
                text: 'Menu Item 4'
            }, {
                text: 'Menu Item 5'
            }]
        }]
    }]
});

var RootNode = ".";
var TreeSome = Ext.create('Ext.data.TreeStore', {
    model: 'Summary',
    storeId: 'myStore',
    proxy: {
        type: 'jsonp',
        url: 'http://localhost:8033/ext/examples/tree/get-nodes.php',
        reader: {
            type: 'json'
        }
    },
    autoLoad: true,
    root: {
        pid: 'www',
        text: 'www',
        expanded: true,
        id: RootNode
    }
});

var Tree = Ext.create('Ext.tree.Panel', {
    store: TreeSome,
    rootVisible: false,
    layout: 'fit',
    fixed: false,
    autoScroll: true,
    height: 500,
    border: 0,
    rootVisible: true,
    id: "main-tree"
});

var fieldEdit = Ext.create("Ext.Editor", {
    field: {
        xtype: 'textfield'
    }
});

Tree.on('itemcontextmenu', function(view, record, item, index, event) {
    var node = record;
    var t = node.get('text');
    var nodeTitle = t.length <= 10 ? t : t.substring(0, 10) + "...";
    var openItem = //open
        {
            text: 'Open',
            icon: 'img/man/templates.png',
            listeners: {
                click: function(a, b) {
                    if (node.get("cls") == "file") {
                        var tId = 'tab-' + node.id;
                        if (document.getElementById(tId)) {
                            return;
                        }
                        var tabs = Ext.getCmp('main-tab');
                        tabs.add({
                            id: tId,
                            title: nodeTitle,
                            bodyPadding: 5,
                            closable: true,
                            html: node.id,
                            tooltip: node.get("id")
                        });
                        tabs.setActiveTab(tId);
                    } else {
                        node.expand();
                    }
                }
            }
        };

    var menuItems = [{
        text: 'Copy',
        icon: 'img/man/page_copy.png',
        listeners: {
            click: function(a, b) {
                var file = {
                    name: node.id,
                    id: node.get("id"),
                    fullPath: node.internalId,
                    parentId: node.get("parentId"),
                    method: "copy"
                };
                myCookie.set("pasteData", Ext.encode(file));
            }
        }
    }, {
        text: 'Cut',
        icon: 'img/man/cut.png',
        listeners: {
            click: function(a, b) {
                var file = {
                    name: node.id,
                    id: node.get("id"),
                    fullPath: node.internalId,
                    parentId: node.get("parentId"),
                    method: "cut"
                };
                item.style.opacity = 0.5;
                myCookie.set("pasteData", Ext.encode(file));
            }
        }
    }, {
        text: 'Rename',
        icon: 'img/man/edit_task.png',
        listeners: {
            click: function(menu, i, e) {
                if (!item) return;
                fieldEdit.startEdit(Ext.get(item), node.get('text'));
                fieldEdit.on('complete', function(me, value) {
                    node.set('text', value);
                    //RENAME ACTION HERE...
                    Tree.store.load({
                        node: node.parentNode
                    });
                }, menu, {
                    single: true
                });
            }
        }
    }, {
        text: 'Delete',
        icon: 'img/man/delete.png',
        listeners: {
            click: function(a, b) {
                Ext.Msg.show({
                    title: 'Confirm deletion?',
                    msg: 'Remove ' + node.get("cls") + ' "' + t + '"?',
                    buttons: Ext.Msg.YESNO,
                    icon: Ext.Msg.QUESTION,
                    fn: function(choose, b, c, d) {
                        if (choose == "yes") {
                            var tId = 'tab-' + node.id;
                            var tabs = Ext.getCmp('main-tab');
                            var tab = Ext.getCmp(tId);
                            if (tab) {
                                tabs.remove(tab);
                            }
                            //REMOVE ACTION HERE...
                            Tree.store.load({
                                node: node.parentNode
                            });
                        }
                    },
                    internalId: node.internalId
                });
            }
        }
    }];
    menuItems.unshift(openItem);
    if (node.get("id") == RootNode) {
        menuItems = [openItem];
    }
    
    if (node.get("cls") != "file") {
    	var newFile = {
                text: 'New File',
                icon: 'img/file.png',
                listeners: {
                    click: function(a, b) {
                        //NEW FILE ACTION HERE...
                    }
                }
            };
        var newDir = {
                text: 'New Folder',
                icon: 'img/directory.png',
                listeners: {
                    click: function(a, b) {
                        //NEW FILE ACTION HERE...
                    }
                }
            };
        menuItems.push(newFile);
        menuItems.push(newDir);
        var pasteData = myCookie.get("pasteData");
        if(pasteData) {
        	var paste = Ext.decode(pasteData);
		    if (paste.id != node.get("id")) {
		        node.expand();
		        var parentNodes = Tree.getStore().getNodeById(paste.parentId);
		        var isCopyOrCut = {
		            text: 'Paste',
		            icon: 'img/man/paste_plain.png',
		            listeners: {
		                click: function(a, b) {
		                    //PASTE ACTION HERE...

		                    node.expand();
		                    Tree.store.load({
		                        node: parentNodes
		                    });
		                    Tree.store.load({
		                        node: node
		                    });
		                    myCookie.clear("pasteData");
		                }
		            }
		        };
		        menuItems.push(isCopyOrCut);
		    }
        }
    }

    var menu1 = new Ext.menu.Menu({
        items: menuItems
    });
    menu1.showAt(event.getXY());
    event.stopEvent();

}, this);

Tree.on('itemdblclick', function(target, record, item, index, e, eOpts) {
    if (record.get("cls") == "file") {
        var node = record;
        var tId = 'tab-' + node.id;
        if (document.getElementById(tId)) {
            return false;
        }
        var t = node.get("text");
        var nodeTitle = t.length <= 10 ? t : t.substring(0, 10) + "...";
        var tabs = Ext.getCmp('main-tab');
        tabs.add({
            id: tId,
            title: nodeTitle,
            bodyPadding: 5,
            closable: true,
            html: node.id,
            tooltip: node.get("id")
        });
        tabs.setActiveTab(tId);
    }
});

//CONTAINER
var Container = function() {
    Ext.create('Ext.container.Viewport', {
        layout: 'border',
        title: 'main title',
        items: [{
            region: 'north',
            border: 0,
            items: [
                Menu
            ],
            margins: '0 0 5 0'
        }, {
            region: 'west',
            title: "Manager",
            collapsible: true,
            xtype: 'tabpanel',
            activeTab: 0,
            id: 'main-tab',
            plain: true,
            maxWidth: 250,
            minWidth: 250,
            manageHeight: true,
            split: true,
            width: 250,
            id: "main-manager",
            items: [{
                icon: 'img/drive.png',
                tooltip: "File Manager",
                closable: false,
                items: [Tree]
            }, {
                icon: 'img/file.png',
                closable: false,
                html: ""
            }]
        }, {
            region: 'south',
            title: 'South Panel',
            collapsible: true,
            html: 'Information goes here',
            split: true,
            height: 100,
            minHeight: 100,
            maxHeight: 400
        }, {
            region: 'east',
            title: 'Discussion',
            layout: "vbox",
            collapsible: true,
            split: true,
            width: 200,
            minWidth: 150,
            maxWidth: 250,
            items: [{
                xtype: "panel",
                width: "100%",
                html: '<br>hello <br>' + Ext.Date.format(new Date(), "Y-m-d H:i:s"),
                flex: 20,
                bodyPadding: 5,
                overflowY: "auto",
                border: 0
            }, {
                xtype: "panel",
                width: "100%",
                flex: 1,
                border: 0,
                items: [{
                    xtype: "textfield",
                    emptyText: "Type here . . .",
                    width: "100%"
                }]
            }]
        }, {
            region: 'center',
            xtype: 'tabpanel',
            activeTab: 0,
            id: 'main-tab',
            plain: true,
            items: [{
                title: 'Realboard',
                tooltip: "Realboard-Client",
                bodyPadding: 5,
                closable: false,
                html: 'The first tab\'s content. Others may be added dynamically'
            }]

        }]
    });
}
Ext.application({
    name: 'Hello Ext',
    launch: Container
});
