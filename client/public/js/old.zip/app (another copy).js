
var IDE = function(target, engine, scope, options){
	
	var self = this;
	
	this.ID = null;
	this.fromServer = false;
	this.activeEngine = engine || "ace";
	this.activeScope = scope || document.body;
	
	this.target = function(obj) {
		var e = document.getElementById(obj);
		if( !e ){
			var o = document.createElement("div");
			o.id = obj;
			self.activeScope.appendChild(o);
			e = document.getElementById(obj);
		}
		e.className = "IDE";
		return e;
	}
	
	this.IDEStyle = function(style){
		var _self = self.editor;
		for(var _style in style) {
			_self.style[_style] = style[_style];
		};
	}
	
	this.loadCss = function(url,attr) {
		var link = document.createElement("link");
		link.rel = "stylesheet";
		link.href = url;
		link.id = url.replace(/[^a-z0-9]/gi,'-').toLowerCase();
		document.getElementsByTagName("head")[0].appendChild(link);
	};
	
	
	
	// setup target object
	this.editor = typeof target != "object" ? this.target(target) : target;
	this.IDE = {};
	
	// setup global options
	this.IDEOptions = {
			App : {
				method 	: {
					send : function(){},
					response : function(){}
				}
			},
			Doc	: {
				ace : {
					enableEmmet			: true,
					mode				: "javascript",
					theme				: "cobalt"
				},
				CodeMirror : {
					value				: "function hello() {\n\tdocument.write(\"Hello\");\n}",
					mode				: "javascript",
					autofocus			: true,
					lineNumbers			: true,
					theme				: "cobalt",
					viewportMargin		: 0,
					indentWithTabs		: true,
					indentUnit			: 4,
					//autoCloseBrackets	: true,
					//styleActiveLine		: true,
					//smartIndent			: true,
					//matchBrackets		: true,
					//keyMap				: "sublime",
					//foldGutter			: true,
					//autoCloseTags		: true,
					//scrollbarStyle		: "overlay",
					//gutters				: [
					//		"CodeMirror-linenumbers", 
					//		"CodeMirror-foldgutter"
					//],
					extraKeys			: {
							"Shift-Ctrl-S":function(cm){
					
							},
							"Ctrl-S":function(cm){
					
							},
							"Shift-Ctrl-R":function(cm){
					
							},
							"Ctrl-Space": "autocomplete",
							"Ctrl-Q": function(cm){
								cm.foldCode(cm.getCursor());
							},
							"F11": function(cm){
					
							},
							"Esc": function(cm){
					
							}
					}
				}
			}
	};
	
	this.engine = {
		
		// ace engine start
		ace : function() {
			var _self = this;
			var _options = self.IDEOptions.Doc[self.activeEngine];
			var _app = self.IDEOptions.App;
			
			self.IDEStyle({position:"absolute",top:0,left:0,bottom:0,right:0});
			
			this.IDE = ace.edit(self.editor);
			if( _options.enableEmmet === true ) {
				_self.IDE.setOption("enableEmmet",true);
			}
			
			this.IDE.setTheme("ace/theme/"+_options.theme);
			this.IDE.setFontSize(14);
			this.IDE.getSession().setMode("ace/mode/"+_options.mode);
			this.IDE.$blockScrolling = Infinity;
			
			_app.method.send = function(change, ed, callback){
				if(callback) {
					return callback(change.data, ed);
				}
			};
			
			_app.method.response = function(data){
				_self.IDE.getSession().getDocument().applyDeltas([data]);
			};
			
			return this.IDE;
		},
		
		// CodeMirror engine start
		CodeMirror : function() {
			var _self = this;
			var _options = self.IDEOptions.Doc[self.activeEngine];
			var _method = self.IDEOptions.App.method;
			if(_options.theme != "default")
				self.loadCss("js/CodeMirror/theme/"+_options.theme+".css");
			
			_self.IDE = CodeMirror(self.editor,_options);
			self.IDEStyle({position:"absolute",top:0,left:0,bottom:0,right:0});
			
			_method.send = function(ed, change, callback){
				if(callback && (change.hasOwnProperty("origin") && change.origin != "setValue") ) {
					return callback(change, ed);
				}
			}
			_method.response = function(data){
				if( typeof data.origin != "undefined" && data.origin == "setValue" ){
					return;
				}
				var _cursor = _self.IDE.getCursor();
				_self.IDE.replaceRange(data.text.join("\n"),data.from,data.to,data.origin);
				if(_cursor.ch != _self.IDE.getCursor().ch) {
					_self.IDE.setCursor(_cursor);
				}
			};
			return this.IDE;
		}
	};
	
	return this;
}

IDE.prototype.Create = function(editor){
//	this.editor = 
	this.IDE = new this.engine[this.activeEngine];
}

IDE.prototype.on = function(method){
		var _IDE = this;
		this.IDE = new this.engine[this.activeEngine];
		var _method = this.IDEOptions.App.method;
		if( method && method.hasOwnProperty("send") ) {
			this.IDE.on("change",function(arg1,arg2){
				if(!_IDE.fromServer) {
					_method.send(arg1,arg2,function(change, ed){
						method.send(change,ed);
					});	
				}
			});	
		}
		if( method && method.hasOwnProperty("response") ) {
			method.response(function(data) {
				_IDE.fromServer = true;
				_method.response(data);
				_IDE.fromServer = false;
			});
		}
		
		return this.IDE;
	};

IDE.prototype.IDEDefinitionLanguage = function(data){
		
};

var socketIDE = function(){};

socketIDE.prototype.open = function(obj){
	this.Container = obj;
};


var socket = io.connect("http://localhost:3000");
socket.on("registered",function(id){
	var o = document.getElementsByClassName("IDE")[0];
	if(o)o.parentNode.removeChild(o);
	
	var e = new IDE("e"+id,"CodeMirror",document.getElementById("editor"));
	e.ID = id;
	e.on({
		send : function(data){
			console.log(data);
			socket.emit("send",data);
		},
		response: function(response){
			socket.on("response",function(data){
				response(data);
			});
		}
	});
});


