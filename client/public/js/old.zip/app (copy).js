
var IDE = function(target, engine, options){
	
	var self = this;
	
	this.ID = null;
	this.fromServer = false;
	
	if ( !engine ) {
		engine = "ace";
	}
	
	this.target = function(obj) {
		return document.getElementById(obj);
	}
	
	this.IDEStyle = function(style){
		var _self = self.editor;
		for(var _style in style) {
			_self.style[_style] = style[_style];
		};
	}
	
	this.loadCss = function(url,attr) {
		var link = document.createElement("link");
		link.rel = "stylesheet";
		link.href = url;
		link.id = url.replace(/[^a-z0-9]/gi,'-').toLowerCase();
		document.getElementsByTagName("head")[0].appendChild(link);
	};
	
	this.loadScript = function(url,callback) {
		var s = document.createElement("script");
		s.src = url;
		s.id = url.replace(/[^a-z0-9]/gi,'-').toLowerCase();
		document.getElementsByTagName("head")[0].appendChild(s);
		s.onload = s.onreadystatechange = function(_, isAbort) {
		    if (isAbort || !s.readyState || s.readyState == "loaded" || s.readyState == "complete") {
		        s = s.onload = s.onreadystatechange = null;
		        if (!isAbort)
		            return callback();
		    }
		};
	};
	
	// setup target object
	this.editor = typeof target != "object" ? this.target(target) : target;
	this.IDE = {};
	
	// setup global options
	this.IDEOptions = {
			App : {
				method 	: {
					send : function(){},
					response : function(){}
				}
			},
			Doc	: {
				ace : {
					enableEmmet			: true,
					mode				: "javascript",
					theme				: "cobalt"
				},
				CodeMirror : {
					value				: "function hello() {\n\tdocument.write(\"Hello\");\n}",
					mode				: "javascript",
					autofocus			: true,
					lineNumbers			: true,
					theme				: "cobalt",
					//styleActiveLine		: true,
					viewportMargin		: 0,
					//autoCloseBrackets	: true,
					indentWithTabs		: true,
					indentUnit			: 4,
					//smartIndent			: true,
					//matchBrackets		: true,
					//keyMap				: "sublime",
					//foldGutter			: true,
					//autoCloseTags		: true,
					//scrollbarStyle		: "overlay",
					//gutters				: [
					//		"CodeMirror-linenumbers", 
					//		"CodeMirror-foldgutter"
					//],
					extraKeys			: {
							"Shift-Ctrl-S":function(cm){
					
							},
							"Ctrl-S":function(cm){
					
							},
							"Shift-Ctrl-R":function(cm){
					
							},
							"Ctrl-Space": "autocomplete",
							"Ctrl-Q": function(cm){
								cm.foldCode(cm.getCursor());
							},
							"F11": function(cm){
					
							},
							"Esc": function(cm){
					
							}
					}
				}
			}
	};
	
	// custom options
	if ( typeof options == "object" && typeof options.Doc != "undefined" ) {
		for(var opt in options){
			this.IDEOptions[opt] = options[opt];
		};
	};
	
	this.engine = {
		
		// ace engine start
		ace : function() {
			var _self = this;
			var _options = self.IDEOptions.Doc[engine];
			var _app = self.IDEOptions.App;
			
			self.IDEStyle({position:"absolute",top:0,left:0,bottom:0,right:0});
			this.IDE = ace.edit(self.editor);
			if( _options.enableEmmet === true ) {
				_self.IDE.setOption("enableEmmet",true);
			}
			
			this.IDE.setTheme("ace/theme/"+_options.theme);
			this.IDE.setFontSize(14);
			this.IDE.getSession().setMode("ace/mode/"+_options.mode);
			this.IDE.$blockScrolling = Infinity;
			
			_app.method.send = function(data, ed, callback){
				if( typeof callback != "function" )
					return;
				return callback(data, ed);
			};
			
			_app.method.response = function(res){
				
				var _res = res.data;
				var s = _res.range.start;
				var e = _res.range.end;
				var text = "";
				switch( _res.action ) {
					case "insertText":
							text = _res.text;
							//+_self.IDE.getSession().getTextRange({
							//	start:{row:e.row,column:e.column},
							//	end:{row:e.row,column:Number.MAX_VALUE}
							//});
							//console.log(text);
						
					break;
					case "removeText":
						text = "";
					break;
					case "insertLines":
						text = _res.lines.join("\n")+"\n";
					break;
					case "removeLines":
						text = "";
					break;
				}
				//_self.IDE.getSession().replace(_res.range, text);
				_self.IDE.getSession().getDocument().applyDeltas([_res]);
			};
			
			return this.IDE;
		},
		
		// CodeMirror engine start
		CodeMirror : function() {
			var _self = this;
			var _options = self.IDEOptions.Doc[engine];
			var _method = self.IDEOptions.App.method;
			if(_options.theme != "default")
				self.loadCss("js/CodeMirror/theme/"+_options.theme+".css");
			
			_self.IDE = CodeMirror(self.editor,_options);
			self.IDEStyle({position:"absolute",top:0,left:0,bottom:0,right:0});
			_method.send = function(ed, change, callback){
				if( change.origin == "setValue" ){
					return;
				}
				if(callback) {
					return callback(change, ed);
				}
			}
			_method.response = function(data){
				if( typeof data.origin != "undefined" && data.origin == "setValue" ){
					return;
				}
				var _cursor = _self.IDE.getCursor();
				_self.IDE.replaceRange(data.text.join("\n"),data.from,data.to,data.origin);
				if(_cursor.ch != _self.IDE.getCursor().ch)
					_self.IDE.setCursor(_cursor);
			};
			return this.IDE;
		}
	};
	
	this.run = function(method){
		self.IDE = new this.engine[engine];
		var _method = self.IDEOptions.App.method;
		if( method && method.hasOwnProperty("onSend") ) {
			self.IDE.on("change",function(arg1,arg2){
				if(!self.fromServer) {
					_method.send(arg1,arg2,function(change, ed){
						method.onSend(change,ed);
					});	
				}
			});	
		}
		if( method && method.hasOwnProperty("onResponse") ) {
			method.onResponse(function(data) {
				self.fromServer = true;
				_method.response(data);
				self.fromServer = false;
			});
		}
		
		return self.IDE;
	};
	return this;
}


var socket = io.connect("http://localhost:3000");
socket.on("registered",function(id){
	var e = new IDE("editor","ace");
	e.ID = id;
	e.run({
		onSend : function(data){
			socket.emit("send",data);
		},
		onResponse: function(response){
			socket.on("response",function(data){
				response(data);
			});
		}
	});
});

